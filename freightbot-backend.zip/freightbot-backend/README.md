# FreightBot Pro — Backend BYOA

Backend Node.js pour l'automatisation des bourses de fret via Playwright.

## Architecture

```
freightbot-backend/
├── server.js                     ← Point d'entrée Express
├── Dockerfile                    ← Pour déploiement Railway
├── .env.example                  ← Variables à copier dans .env
├── api/
│   └── routes.js                 ← Endpoints REST
├── services/
│   ├── transeu.js                ← Script Playwright Trans.eu
│   ├── scorer.js                 ← Algorithme de scoring IA
│   ├── credentialsVault.js       ← Chiffrement AES-256
│   └── logger.js                 ← Logger Winston
└── jobs/
    └── scanJob.js                ← Cron scan toutes les 8 min
```

## Installation locale

```bash
# 1. Cloner et installer
npm install

# 2. Installer Chromium
npm run install:browser

# 3. Configurer l'environnement
cp .env.example .env
# Éditer .env avec votre ENCRYPTION_KEY

# 4. Lancer
npm run dev
```

## Endpoints API

### Connexion d'un compte bourse
```
POST /api/connect
{
  "userId": "user_123",
  "bourseId": "transeu",
  "username": "login@email.com",
  "password": "motdepasse",
  "filters": {
    "fromCountry": "FR",
    "toCountry": "FR",
    "minWeight": 10
  }
}
```

### Déconnexion
```
POST /api/disconnect
{ "userId": "user_123", "bourseId": "transeu" }
```

### Statut bot
```
GET /api/status/user_123
```

### Récupérer les offres scorées
```
GET /api/offers/user_123?minScore=80&maxResults=20
```

### Forcer un scan immédiat
```
POST /api/scan/user_123
```

### Logs bot en temps réel
```
GET /api/logs/user_123
```

### Health check
```
GET /health
```

## Déploiement sur Railway

1. Créer un compte sur https://railway.app
2. Nouveau projet → "Deploy from GitHub repo"
3. Connecter votre repo GitHub (pousser ce dossier dessus)
4. Railway détecte automatiquement le Dockerfile
5. Dans "Variables" ajouter :
   - `ENCRYPTION_KEY` = une chaîne aléatoire de 32+ caractères
   - `FRONTEND_URL` = URL de votre app Lovable
   - `NODE_ENV` = production
6. Deploy → Railway génère une URL publique

## Intégration avec le frontend Lovable

Dans votre app Lovable, appeler le backend ainsi :

```typescript
const API_URL = "https://votre-app.railway.app";

// Connecter un compte bourse
await fetch(`${API_URL}/api/connect`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ userId, bourseId: "transeu", username, password })
});

// Récupérer les offres
const res = await fetch(`${API_URL}/api/offers/${userId}?minScore=70`);
const { offers, stats } = await res.json();

// Polling logs bot toutes les 5 secondes
setInterval(async () => {
  const res = await fetch(`${API_URL}/api/logs/${userId}`);
  const { logs } = await res.json();
  setLogs(logs);
}, 5000);
```

## Notes importantes

- Les sélecteurs Playwright dans `transeu.js` doivent être ajustés selon
  la structure HTML réelle du site Trans.eu (elle peut évoluer)
- En production, remplacer le vault en mémoire par une base de données
  chiffrée (PostgreSQL + pgcrypto ou Redis)
- Respecter les CGU de votre abonnement Trans.eu (usage BYOA = usage personnel)
