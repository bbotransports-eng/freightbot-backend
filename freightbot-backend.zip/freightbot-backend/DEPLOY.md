# Déploiement Railway — Guide étape par étape

## Prérequis
- Compte GitHub (gratuit)
- Compte Railway : https://railway.app (gratuit pour commencer)

---

## ÉTAPE 1 — Préparer le repo GitHub

1. Créer un nouveau repo GitHub (ex: `freightbot-backend`)
2. Copier tous les fichiers de ce dossier dans le repo
3. S'assurer que `.env` est dans `.gitignore` (ne jamais pusher les secrets)

```bash
# .gitignore
node_modules/
.env
*.log
```

4. Pusher sur GitHub :
```bash
git init
git add .
git commit -m "Initial FreightBot backend"
git remote add origin https://github.com/VOTRE_COMPTE/freightbot-backend.git
git push -u origin main
```

---

## ÉTAPE 2 — Créer le projet Railway

1. Aller sur https://railway.app → "New Project"
2. Choisir "Deploy from GitHub repo"
3. Sélectionner votre repo `freightbot-backend`
4. Railway détecte le Dockerfile automatiquement → cliquer "Deploy"

---

## ÉTAPE 3 — Configurer les variables d'environnement

Dans Railway → onglet "Variables" → ajouter une par une :

### Variables obligatoires (Phase 1 — mode mock)

| Variable | Valeur |
|----------|--------|
| `NODE_ENV` | `production` |
| `PORT` | `3001` |
| `MOCK_MODE` | `true` |
| `ENCRYPTION_KEY` | Une chaîne aléatoire 32+ caractères |
| `FRONTEND_URL` | `https://votre-app.lovable.app` |
| `SCAN_INTERVAL_MINUTES` | `8` |

### Générer une ENCRYPTION_KEY solide
```bash
# Sur votre terminal local :
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Variables à ajouter plus tard (Phase 2 — mode réel)

| Variable | Valeur |
|----------|--------|
| `MOCK_MODE` | `false` (changer quand clés reçues) |
| `TRANSEU_CLIENT_ID` | Reçu de Trans.eu |
| `TRANSEU_CLIENT_SECRET` | Reçu de Trans.eu |
| `TRANSEU_API_KEY` | Reçu de Trans.eu |

---

## ÉTAPE 4 — Récupérer l'URL publique

1. Dans Railway → onglet "Settings" → "Networking"
2. Cliquer "Generate Domain"
3. Railway génère une URL du type : `https://freightbot-backend-production.up.railway.app`
4. **Copier cette URL** — vous en aurez besoin pour Lovable

---

## ÉTAPE 5 — Vérifier que ça tourne

Ouvrir dans le navigateur :
```
https://votre-url.railway.app/health
```

Réponse attendue :
```json
{
  "status": "ok",
  "uptime": 12,
  "env": "production",
  "timestamp": "2024-06-10T14:32:00.000Z"
}
```

---

## ÉTAPE 6 — Tester l'API avec le mode mock

### Test 1 : Démarrer le bot (sans credentials en mode mock)
```bash
curl -X POST https://votre-url.railway.app/api/connect \
  -H "Content-Type: application/json" \
  -d '{"userId": "test_user_1", "bourseId": "transeu"}'
```

Réponse attendue :
```json
{
  "success": true,
  "message": "Compte transeu connecté, bot démarré (mode mock)",
  "mock": true
}
```

### Test 2 : Attendre 3-4 secondes puis récupérer les offres
```bash
curl https://votre-url.railway.app/api/offers/test_user_1
```

Réponse attendue : liste de 6-8 offres scorées

### Test 3 : Voir les logs du bot
```bash
curl https://votre-url.railway.app/api/logs/test_user_1
```

### Test 4 : Forcer un scan immédiat
```bash
curl -X POST https://votre-url.railway.app/api/scan/test_user_1
```

---

## ÉTAPE 7 — Connecter Lovable au backend

Dans Lovable :
1. "Settings" → "Environment Variables"
2. Ajouter : `VITE_API_URL` = `https://votre-url.railway.app`
3. Redéployer l'app Lovable

---

## Passage en mode réel (quand clés API reçues)

1. Dans Railway → Variables
2. Changer `MOCK_MODE` de `true` à `false`
3. Ajouter `TRANSEU_CLIENT_ID`, `TRANSEU_CLIENT_SECRET`, `TRANSEU_API_KEY`
4. Railway redémarre automatiquement le serveur

---

## Coûts Railway

| Usage | Prix |
|-------|------|
| Dev / test (< 500h/mois) | Gratuit |
| Production légère | ~5$/mois |
| Avec base de données PostgreSQL | ~10$/mois |

---

## En cas de problème

### Logs en temps réel
Railway → onglet "Deployments" → cliquer sur le déploiement → "View Logs"

### Erreur "Port already in use"
Vérifier que la variable `PORT=3001` est bien définie dans Railway Variables.

### Erreur CORS
Vérifier que `FRONTEND_URL` correspond exactement à l'URL de votre app Lovable
(sans slash final, avec https://).
